package ITTEntity;


import java.sql.SQLException;
import java.sql.Connection;

import java.sql.ResultSet;
import java.sql.Statement;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.SessionScoped;

import javax.faces.context.FacesContext;
import javax.faces.application.FacesMessage;
import java.sql.PreparedStatement;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;


 
  
@ManagedBean(name="loginBean")
@SessionScoped
public class LoginBean {

    
    private String userName;
    private String password;
    private String dbuserName;
    private String address;
    private String phone;
    private String name;
    private String date;
    private String staffid;
    private String staffname;
    private String package_id;
    private String package_name;
    private String venue;
    private String assigned_staff;
    private String updatebkd;
    private Double price;
    private Double gst;
    private Double net_price;

   
            
    
    public String getUpdatebkd() {
        return updatebkd;
    }

    public void setUpdatebkd(String updatebkd) {
        this.updatebkd = updatebkd;
    }
    

    public String getAssigned_staff() {
        return assigned_staff;
    }

    public void setAssigned_staff(String assigned_staff) {
        this.assigned_staff = assigned_staff;
    }

    public String getVenue() {
        return venue;
    }

    public void setVenue(String venue) {
        this.venue = venue;
    }
    public String getPackage_id() {
        return package_id;
    }

    public void setPackage_id(String package_id) {
        this.package_id = package_id;
    }

    public String getPackage_name() {
        return package_name;
    }

    public void setPackage_name(String package_name) {
        this.package_name = package_name;
    }

    public String getStaffname() {
        return staffname;
    }

    public void setStaffname(String staffname) {
        this.staffname = staffname;
    }

    public String getDate() {
        return date;
    }

    public void setDate(String date) {
        this.date = date;
    }

    public String getStaffid() {
        return staffid;
    }

    public void setStaffid(String staffid) {
        this.staffid = staffid;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public String getPhone() {
        return phone;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }
    

   
  
    private String dbpassword;
    Connection connection;
    Statement statement;
    ResultSet resultSet;
    String SQL;
    
   
  
    public String getUserName() {
        return userName;
    }
 
    public void setUserName(String userName) {
        this.userName = userName;
    }
 
    public String getPassword() {
        return password;
    }
 
    public void setPassword(String password) {
        this.password = password;
    }
 
    public String getDbuserName() {
        return dbuserName;
    }
 
    public void setDbuserName(String dbuserName) {
        this.dbuserName = dbuserName;
    }
 
    public String getDbpassword() {
        return dbpassword;
    }
 
    public void setDbpassword(String dbpassword) {
        this.dbpassword = dbpassword;
    }
 
    public void dbCustData(String userName)
    {
        try
        {
            
            connection = ConnectionBean.getConnection();
            statement = connection.createStatement();
            SQL = "Select * from customer where customer_email like ('" + userName +"')";
            resultSet = statement.executeQuery(SQL);
            resultSet.next();
            dbuserName = resultSet.getString(1).toString();
            dbpassword = resultSet.getString(2).toString();
        }
        catch(Exception ex)
        {
            ex.printStackTrace();
            System.out.println("Exception Occured in the process :" + ex);
        }
    }
     
    public String checkValidCustomer()
    {
        dbCustData(userName);
  
        if(userName.equalsIgnoreCase(dbuserName))
        {
  
            if(password.equals(dbpassword))
            {    
              
                return "success";}
            else
            {   
                FacesContext.getCurrentInstance().addMessage(
                    null,
                    new FacesMessage(FacesMessage.SEVERITY_WARN,
                            "Incorrect Username and Passowrd",
                            "Please enter correct username and Password"));
                return "failure";
            }
        }
        else
        {   
            FacesContext.getCurrentInstance().addMessage(
                    null,
                    new FacesMessage(FacesMessage.SEVERITY_WARN,
                            "Incorrect Username and Passowrd",
                            "Please enter correct username and Password"));
            return "failure";
        }
    }

public void dbStaffData(String userName)
    {
        try
        {
            
            connection = ConnectionBean.getConnection();
            statement = connection.createStatement();
            SQL = "Select * from staff where staff_id like ('" + userName +"')";
            resultSet = statement.executeQuery(SQL);
            resultSet.next();
            dbuserName = resultSet.getString(1).toString();
            dbpassword = resultSet.getString(2).toString();
        }
        catch(Exception ex)
        {
            ex.printStackTrace();
            System.out.println("Exception Occured in the process :" + ex);
        }
    }
     
    public String checkValidStaff()
    {
        dbStaffData(userName);
  
        if(userName.equalsIgnoreCase(dbuserName))
        {
  
            if(password.equals(dbpassword))
                return "success";
            else
            {
                return "failure";
            }
        }
        else
        {
            return "failure";
        }
    }
    
    public Customer getCustomerDetail() throws ClassNotFoundException 
    {
        Customer c = new Customer();
        try {
            
            
            connection = ConnectionBean.getConnection();
            
            
            statement = connection.createStatement();
            SQL = "Select * from customer where customer_email like ('" + dbuserName +"')";
            resultSet = statement.executeQuery(SQL);
            resultSet.next();
            
            
            
            
            c.setCustomerEmail(resultSet.getString("customer_email"));
            c.setCustomerName(resultSet.getString("customer_name"));
            c.setCustomerAddress(resultSet.getString("customer_address"));
            c.setCustomerPhone(resultSet.getString("customer_phone"));
            c.setCustomerPassword(resultSet.getString("customer_password"));
            
            
            
            
            
            
        } catch (SQLException ex) {
            Logger.getLogger(LoginBean.class.getName()).log(Level.SEVERE, null, ex);
        }
        return c;
    }
     public String updateUser() throws ClassNotFoundException, SQLException
    {
       
           connection = ConnectionBean.getConnection();
           
             PreparedStatement pStatement = connection
                     
                     .prepareStatement("update customer set customer_password=?, customer_address=?,customer_phone=?,customer_name=?" 
                     +"where customer_email=?");
                     
                             
             pStatement.setString(1, password);
             pStatement.setString(2, address);
             pStatement.setString(3, phone);
             pStatement.setString(4, name);
             pStatement.setString(5, dbuserName);
             pStatement.executeUpdate();
             
           
        return "updated"; 
    }
     //get List of staff's name
      public List getStaffList() throws ClassNotFoundException,SQLException {
    List<String> list = new ArrayList<>(); 
    String name;
    try {
            
            
            connection = ConnectionBean.getConnection();
            
            
            statement = connection.createStatement();
            SQL = "Select * from staff;";
            resultSet = statement.executeQuery(SQL);
            
            
            while(resultSet.next()){
			
			
			name=(resultSet.getString("staff_name"));
			
			
			//store all data into a List
			list.add(name);
                        
		}
            
            
            
    
            
            
        } catch (SQLException ex) {
            Logger.getLogger(LoginBean.class.getName()).log(Level.SEVERE, null, ex);
        }
        return list;
    
    
}
      //get staff class based on staff id
      
      public Staff getStaff (String staffID) throws SQLException, ClassNotFoundException{
          Staff staff = new Staff();
          
          connection = ConnectionBean.getConnection();
            
            
            statement = connection.createStatement();
            SQL = "Select * from staff where staff_id like ('"+staffID+"')";
            resultSet = statement.executeQuery(SQL);
            resultSet.next();
            
            staff.setStaffId(staffID);
            staff.setStaffEmail(resultSet.getString("staff_email"));
            staff.setStaffPassword(resultSet.getString("staff_password"));
            staff.setStaffName(resultSet.getString("staff_name"));
            staff.setStaffIc(resultSet.getString("staff_ic"));
            
            assigned_staff = resultSet.getString("staff_email");
          return staff;
          
      }
              
public String create_bookingdate() throws SQLException, ClassNotFoundException {
    String staff = getStaffID();
    
    connection =ConnectionBean.getConnection();
        statement = connection.createStatement();
        SQL="select * from bookingdate where date ='"+date+"'";
        resultSet=statement.executeQuery(SQL);
        while(resultSet.next())
        {
            String st = resultSet.getString("staff_id");
            if(st.equalsIgnoreCase(staff))
            {
                connection.close();
                return "abort";
            }
               
        }
    connection = ConnectionBean.getConnection();
             PreparedStatement preparedStatement = connection
                     .prepareStatement("insert into bookingdate(staff_id,date,package_id,venue) values (?, ?, ?, ?)");
            
             preparedStatement.setString(1, staff);
             preparedStatement.setString(2, date);
             package_id=getPackageID();
             preparedStatement.setString(3, package_id);
             preparedStatement.setString(4, venue);
             
             preparedStatement.executeUpdate();
             connection.close();
             return "created";

}
public String getStaffID() throws ClassNotFoundException, SQLException{
    connection = ConnectionBean.getConnection();
        statement = connection.createStatement();
             SQL = "Select staff_id from staff where staff_name like ('" + staffname +"')";
            resultSet=statement.executeQuery(SQL);
            resultSet.next();
            staffid=resultSet.getString(1).toString();
            connection.close();
            return staffid;
}

   public List getPackageList() throws ClassNotFoundException,SQLException {
    List<String> list = new ArrayList<>(); 
    String packagename;
    try {
            
            
            connection = ConnectionBean.getConnection();
            
            
            statement = connection.createStatement();
            SQL = "Select * from package;";
            resultSet = statement.executeQuery(SQL);
            
            
            while(resultSet.next()){
			
			
			packagename=(resultSet.getString("package_name"));
			
			
			//store all data into a List
			list.add(packagename);
                        
		}
            
            
            
    
            
            
        } catch (SQLException ex) {
            Logger.getLogger(LoginBean.class.getName()).log(Level.SEVERE, null, ex);
        }
        return list;       
   }
   //getPackageID based on Package Name
   public String getPackageID() throws ClassNotFoundException, SQLException{
    connection = ConnectionBean.getConnection();
        statement = connection.createStatement();
             SQL = "Select package_id from package where package_name like ('" + package_name +"')";
            resultSet=statement.executeQuery(SQL);
            resultSet.next();
            String packages=resultSet.getString(1).toString();
            connection.close();
            return packages;
   }
   //get Package Class based on PackageID


   public String getLastBookingID() throws ClassNotFoundException, SQLException{
       String bookingID;
   connection =ConnectionBean.getConnection();
   statement=connection.createStatement();
   SQL="select date_id from bookingdate order by date_id desc limit 1";
   resultSet=statement.executeQuery(SQL);
   resultSet.next();
   bookingID = resultSet.getString(1).toString();
   return bookingID;
   }
   public String createBooking () throws SQLException, ClassNotFoundException{
       String date_id = getLastBookingID();
       String package_ID=getPackageID();
       
    
    connection = ConnectionBean.getConnection();
             PreparedStatement preparedStatement = connection
                     .prepareStatement("insert into booking(customer_email,date_id) values (?, ?)");
            
             preparedStatement.setString(1, dbuserName);
             preparedStatement.setString(2, date_id);
      
             
             preparedStatement.executeUpdate();
             connection.close();
             
   return "success";
   }
   //get particular customer booking list
   public List<Bookingdate> getBookingList() throws ClassNotFoundException, SQLException{
   
       List<Bookingdate> list = new ArrayList<>();
       
       connection=ConnectionBean.getConnection();
       statement=connection.createStatement();
       SQL="select bookingdate.date_id,bookingdate.staff_id,bookingdate.date,bookingdate.package_id,bookingdate.venue from bookingdate,booking\n" +
            "where bookingdate.date_id=booking.date_id and booking.customer_email like ('"+dbuserName+"')";
       
       resultSet = statement.executeQuery(SQL);
       while(resultSet.next()){
       
        Bookingdate a =new Bookingdate();
       
            a.setDateId(resultSet.getInt("date_id"));
            a.setDate(resultSet.getString("date"));
            a.setPackageId(resultSet.getString("package_id"));
            a.setStaffId(resultSet.getString("staff_id"));
            a.setVenue(resultSet.getString("venue"));
       
            list.add(a);
       }
       return list;
   }
   //get All Booking List
   public List<Bookingdate> getAllBookingList() throws ClassNotFoundException, SQLException{
   
       List<Bookingdate> list = new ArrayList<>();
       
       connection=ConnectionBean.getConnection();
       statement=connection.createStatement();
       SQL="select bookingdate.date_id,bookingdate.staff_id,bookingdate.date,bookingdate.package_id,bookingdate.venue from bookingdate,booking\n" +
            "where bookingdate.date_id=booking.date_id";
       
       resultSet = statement.executeQuery(SQL);
       while(resultSet.next()){
       
        Bookingdate a =new Bookingdate();
       
            a.setDateId(resultSet.getInt("date_id"));
            a.setDate(resultSet.getString("date"));
            a.setPackageId(resultSet.getString("package_id"));
            a.setStaffId(resultSet.getString("staff_id"));
            a.setVenue(resultSet.getString("venue"));
       
            list.add(a);
       }
       return list;
   }
   //delete a booking
   public void deletebookingPart1(Bookingdate bdate) throws ClassNotFoundException, SQLException{
       int dateid=bdate.getDateId();
       
       connection = ConnectionBean.getConnection();
       statement = connection.createStatement();
       SQL = "delete from booking "
               + "where date_id = "+dateid ;
       statement.executeUpdate(SQL);
       connection.close();
       deletebookingPart2(dateid);
       
   }
   //delete a bookingdate
   public void deletebookingPart2(int id) throws ClassNotFoundException, SQLException{
       
       
       connection = ConnectionBean.getConnection();
       statement = connection.createStatement();
       SQL = "delete from bookingdate "
               + "where date_id = "+id ;
       statement.executeUpdate(SQL);
       connection.close();
   }
   public String createCustomerPart1()
   {
       return "registration";
   }
   public String createCustomerPart2() throws ClassNotFoundException, SQLException{
       connection = ConnectionBean.getConnection();
        PreparedStatement preparedStatement = connection
                     .prepareStatement("insert into customer(customer_email,customer_password,customer_name,customer_phone,customer_address) "
                             + "values (?, ?, ?, ?, ?)");
        
        preparedStatement.setString(1, userName);
        preparedStatement.setString(2, password);
        preparedStatement.setString(3, name);
        preparedStatement.setString(4, phone);
        preparedStatement.setString(5, address);
        
        preparedStatement.executeUpdate();
        connection.close();
        
       
       return "registration2";
   }
   //update a booking
   public String updateBookingPart1(String id){
       updatebkd=id;
       return "update_bookingdate";
   }
   public String updateBookingPart2() throws ClassNotFoundException, SQLException
   {
       connection = ConnectionBean.getConnection();
        PreparedStatement preparedStatement = connection
                     .prepareStatement("update bookingdate set staff_id=?, date=?, package_id=?, venue=?" 
                     +"where date_id=?");
        //update later
        staffid=getStaffID();
        preparedStatement.setString(1, staffid);
        preparedStatement.setString(2, date);
        package_id=getPackageID();
        preparedStatement.setString(3, package_id);
        preparedStatement.setString(4, venue);
        preparedStatement.setString(5, updatebkd);
        
         preparedStatement.executeUpdate();
         connection.close();
        
      return "updated";
      
   }
   //return package class
   public Package getPackage(String id) throws ClassNotFoundException, SQLException{
       Package p = new Package(); 
       connection = ConnectionBean.getConnection();
        statement = connection.createStatement();
        SQL = "select * from package where package_id like ('"+id+"')";
        resultSet = statement.executeQuery(SQL);
        resultSet.next();
        
        p.setPackageId(resultSet.getString("package_id"));
        p.setPackagePrice(resultSet.getDouble("package_price"));
        p.setPackageName(resultSet.getString("package_name"));
        
        return p;
        
        
   }
           
           
   public String Bill(Bookingdate bkd) throws ClassNotFoundException, SQLException{
       date = bkd.getDate();
       venue = bkd.getVenue();
       Customer c = getCustomerDetail();
       name = c.getCustomerName();
       phone = c.getCustomerPhone();
       address = c.getCustomerAddress();
       Staff s = getStaff(bkd.getStaffId());
       staffid = bkd.getStaffId();
       staffname = s.getStaffName();
       Package p = getPackage(bkd.getPackageId());
       price = p.getPackagePrice();
       gst = (price+300) * 0.06;
       net_price = price + gst + 300 ;
       package_name= p.getPackageName();
       package_id = p.getPackageId();
       
       return "bill";
   
   }
   
   
   /*---------------------------------STAFF FUNCTION HERE-----------------------------------------------*/

    public Double getPrice() {
        return price;
    }

    public void setPrice(Double price) {
        this.price = price;
    }

    public Double getGst() {
        return gst;
    }

    public void setGst(Double gst) {
        this.gst = gst;
    }

    public Double getNet_price() {
        return net_price;
    }

    public void setNet_price(Double net_price) {
        this.net_price = net_price;
    }
  
  
   }
           
           

   
    

   

