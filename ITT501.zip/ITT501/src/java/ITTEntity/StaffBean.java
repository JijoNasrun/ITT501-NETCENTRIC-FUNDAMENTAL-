/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ITTEntity;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.RequestScoped;

/**
 *
 * @author JIJO
 */
@ManagedBean
@RequestScoped
public class StaffBean {

     private String packid;
    private double packprice;
    private String packname;
    Connection connection;
    Statement statement;
    ResultSet resultSet;
    String SQL;

    public String getPackid() {
        return packid;
    }

    public void setPackid(String packid) {
        this.packid = packid;
    }

    public double getPackprice() {
        return packprice;
    }

    public void setPackprice(double packprice) {
        this.packprice = packprice;
    }

    public String getPackname() {
        return packname;
    }

    public void setPackname(String packname) {
        this.packname = packname;
    }
    
    public String createPackage() throws ClassNotFoundException, SQLException{
        
        connection = ConnectionBean.getConnection();
        
        PreparedStatement pStatement = connection
                     
                     .prepareStatement("insert into package(package_id,package_price,package_name) values ( ?, ?, ?)");
        
         pStatement.setString(1, packid);
         pStatement.setDouble(2, packprice);
         pStatement.setString(3, packname);
         
         pStatement.executeUpdate();
         return "created";
    }
    
}
