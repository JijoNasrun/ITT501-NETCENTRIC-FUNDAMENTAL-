/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ITTEntity;

import java.io.Serializable;
import java.util.Collection;
import java.util.Date;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlTransient;

/**
 *
 * @author JIJO
 */
@Entity
@Table(name = "bookingdate")
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "Bookingdate.findAll", query = "SELECT b FROM Bookingdate b"),
    @NamedQuery(name = "Bookingdate.findByDateId", query = "SELECT b FROM Bookingdate b WHERE b.dateId = :dateId"),
    @NamedQuery(name = "Bookingdate.findByDate", query = "SELECT b FROM Bookingdate b WHERE b.date = :date")})
public class Bookingdate implements Serializable {
    @Size(max = 10)
    @Column(name = "package_id")
    private String packageId;
    @Size(max = 45)
    @Column(name = "venue")
    private String venue;
    private static final long serialVersionUID = 1L;
    @Id
    @Basic(optional = false)
    @NotNull
    @Column(name = "date_id")
    private Integer dateId;
    @Column(name = "date")
    @Temporal(TemporalType.DATE)
    private String date;
    @OneToMany(mappedBy = "dateId")
    private Collection<Booking> bookingCollection;
    @JoinColumn(name = "staff_id", referencedColumnName = "staff_id")
    @ManyToOne
    private String staffId;
    @JoinColumn(name = "booking_id", referencedColumnName = "booking_id")
    @ManyToOne
    private String bookingId;
    
    public Bookingdate(){}

    public Bookingdate(Bookingdate b) {
        staffId = b.staffId;
        date = b.date;
        dateId=b.dateId;
        packageId=b.packageId;
        venue=b.venue;
    }

    public Bookingdate(Integer dateId) {
        this.dateId = dateId;
    }

    public Integer getDateId() {
        return dateId;
    }

    public void setDateId(Integer dateId) {
        this.dateId = dateId;
    }

    public String getDate() {
        return date;
    }

    public void setDate(String date) {
        this.date = date;
    }

    @XmlTransient
    public Collection<Booking> getBookingCollection() {
        return bookingCollection;
    }

    public void setBookingCollection(Collection<Booking> bookingCollection) {
        this.bookingCollection = bookingCollection;
    }

    public String getStaffId() {
        return staffId;
    }

    public void setStaffId(String staffId) {
        this.staffId = staffId;
    }

    public String getBookingId() {
        return bookingId;
    }

    public void setBookingId(String bookingId) {
        this.bookingId = bookingId;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (dateId != null ? dateId.hashCode() : 0);
        return hash;
    }

 
    @Override
    public String toString() {
        return "ITTEntity.Bookingdate[ dateId=" + dateId + " ]";
    }

    public String getPackageId() {
        return packageId;
    }

    public void setPackageId(String packageId) {
        this.packageId = packageId;
    }

    public String getVenue() {
        return venue;
    }

    public void setVenue(String venue) {
        this.venue = venue;
    }
    
}
